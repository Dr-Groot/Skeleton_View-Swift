//
//  Constants.swift
//  SkeletonViewDemo
//
//  Created by Amam Pratap Singh on 20/01/23.
//

import Foundation

struct Constants {
    static let cornerRadius: Int = 10
    static let lastLineFillPercent: Int = 70
    static let lineSpacing: CGFloat = 10
    static let lineHeight: CGFloat = 15
    static let profileDescription: String = "Android Developer || UI/UX || Mobile app platforms || Programming languages and tools || Cyber security awareness || Agile developmend || Backend computing || Web development languages like HTML 5 and CSS || Business capability."
}
