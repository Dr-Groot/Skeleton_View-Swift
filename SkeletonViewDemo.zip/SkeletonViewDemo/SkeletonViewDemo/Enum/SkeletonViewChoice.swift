//
//  SkeletonViewChoice.swift
//  SkeletonViewDemo
//
//  Created by Amam Pratap Singh on 18/01/23.
//

import Foundation

enum SkeletonViewChoice {
    case solid
    case gradient
    case solidAnimated
    case gradientAnimated
}
