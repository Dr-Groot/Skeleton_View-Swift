//
//  ProfileDataModel.swift
//  SkeletonViewDemo
//
//  Created by Amam Pratap Singh on 19/01/23.
//

import Foundation

class ProfileDataModel {
    struct Profile {
        let title: String
        let description: String
        let image: String
    }

    let data: [Profile]  = [
        Profile(title: "Abhay", description: "Android Developer, who is charged with designing and coding software for businesses and consumers alike", image: "profile"),
        Profile(title: "Nimish", description: "iOS Developer, who is charged with designing and coding software for businesses and consumers alike", image: "profile"),
        Profile(title: "Gamma", description: "Java Developer, who is charged with designing and coding software for businesses and consumers alike", image: "profile"),
        Profile(title: "Alpha", description: "Python Developer, who is charged with designing and coding software for businesses and consumers alike", image: "profile"),
        Profile(title: "Beta", description: "C# Developer, who is charged with designing and coding software for businesses and consumers alike", image: "profile")
    ]
}
