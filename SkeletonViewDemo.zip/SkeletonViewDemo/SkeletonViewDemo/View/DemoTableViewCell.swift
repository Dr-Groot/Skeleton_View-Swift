//
//  DemoTableViewCell.swift
//  SkeletonViewDemo
//
//  Created by Amam Pratap Singh on 19/01/23.
//

import UIKit
import SkeletonView

class DemoTableViewCell: UITableViewCell {

    static let identifier = "DemoTableViewCell"

    @IBOutlet var profileImageView: UIImageView!
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var DescriptionLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()

        setSkeletonable()
    }

//  Set Skeletonable
    private func setSkeletonable() {
        profileImageView.isSkeletonable = true
        nameLabel.isSkeletonable = true
        DescriptionLabel.isSkeletonable = true
    }

//  Showing Skeleton when data is unloaded
    func setData(loaded: Bool) {
        let gradient = SkeletonGradient(baseColor: UIColor.wetAsphalt)
        if loaded {
            nameLabel.hideSkeleton()
            profileImageView.hideSkeleton()
            DescriptionLabel.hideSkeleton()
        } else {
            nameLabel.showAnimatedGradientSkeleton(usingGradient: gradient)
            profileImageView.showAnimatedGradientSkeleton(usingGradient: gradient)
            DescriptionLabel.showAnimatedGradientSkeleton(usingGradient: gradient)
        }
    }

}
