//
//  ViewController.swift
//  SkeletonViewDemo
//
//  Created by Amam Pratap Singh on 18/01/23.
//

import UIKit
import SkeletonView
import Instructions

class ViewController: UIViewController {

    @IBOutlet var profileImageView: UIImageView!
    @IBOutlet var profileNameLabel: UILabel!
    @IBOutlet var profileDescriptionLabel: UILabel!
    @IBOutlet var skeletonSwitch: UISwitch!
    @IBOutlet var skeletonType: [UIButton]!
    @IBOutlet var lineCornerRadiusTextField: UITextField!
    @IBOutlet var aboutLabel: UILabel!
    @IBOutlet var lastLineFillPercentTextField: UITextField!
    @IBOutlet var lineSpacingTextField: UITextField!
    @IBOutlet var lineHeightTextField: UITextField!
    @IBOutlet var selectSkeletonTypeButton: UIButton!
    @IBOutlet var skeletonPropertyView: UIView!
    @IBOutlet var skeletonTypeView: UIView!
    @IBOutlet var showTableViewButton: UIButton!

    private var buttonOn: Bool = false
    private var skeletonChoice: SkeletonViewChoice?
    private var cornerRadius: Int = Constants.cornerRadius
    private var lastLineFillPercent: Int = Constants.lastLineFillPercent
    private var lineSpacing: CGFloat = Constants.lineSpacing
    private var lineHeight: CGFloat = Constants.lineHeight

    let coachMarksController = CoachMarksController()

    override func viewDidLoad() {
        super.viewDidLoad()

        configCoachMarks()
        configTheme()
        configDependency()
        isSkeletonInitalization()

//      Started Instructions
        DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: {
            self.coachMarksController.start(in: .viewController(self))
        })
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.coachMarksController.stop(immediately: true)
    }

//  Instruction Setup
    private func configCoachMarks() {
        self.coachMarksController.dataSource = self
        self.coachMarksController.delegate = self

        let skipView = CoachMarkSkipDefaultView()
        skipView.setTitle("Skip", for: .normal)

        self.coachMarksController.skipView = skipView
    }

//  Setting up Skeleton View
    private func isSkeletonInitalization() {
        profileImageView.isSkeletonable = true
        profileNameLabel.isSkeletonable = true
        profileDescriptionLabel.isSkeletonable = true
        aboutLabel.isSkeletonable = true
    }

//  Theme
    private func configTheme() {
        self.navigationItem.title = "Main Page"
        profileImageView.layer.cornerRadius = 25
        profileNameLabel.textColor = UIColor.white
        profileDescriptionLabel.textColor = UIColor.white
    }

//  Dependency
    private func configDependency() {
        skeletonSwitch.isOn = false

        profileNameLabel.text = "Skeleton View"
        profileDescriptionLabel.text = Constants.profileDescription
    }

//  Switch Button Set
    @IBAction func didTapSkeletonSwitch(_ sender: UISwitch) {
        if skeletonSwitch.isOn {
            buttonOn = true
            setSkeletionAppearance(
                cornerRadius: cornerRadius,
                lastLineFillPercent: lastLineFillPercent,
                lineSpacing: lineSpacing,
                lineHeight: lineHeight
            )
            selectSekeltonTypeShimmer(type: .solid)
        } else {
            buttonOn = false
            hideSkeleton()
            resetSkeletonApperance()
        }
    }

//  Drop Down option for selecting Sekelton Type
    @IBAction func didTapSelectSkeletionType(_ sender: UIButton) {
        skeletonType.forEach { (Button) in
            UIView.animate(withDuration: 0.3, animations: {
                Button.isHidden = !Button.isHidden
                self.view.layoutIfNeeded()
            })
        }
    }

//  Solid Skeleton Type Button
    @IBAction func didTapSolidButton(_ sender: UIButton) {
        setSkeletionAppearance(
            cornerRadius: cornerRadius,
            lastLineFillPercent: lastLineFillPercent,
            lineSpacing: lineSpacing,
            lineHeight: lineHeight
        )
        selectSekeltonTypeShimmer(type: .solid)
    }

//  Gradient Skeleton Type Button
    @IBAction func didTapGradientButton(_ sender: UIButton) {
        setSkeletionAppearance(
            cornerRadius: cornerRadius,
            lastLineFillPercent: lastLineFillPercent,
            lineSpacing: lineSpacing,
            lineHeight: lineHeight
        )
        selectSekeltonTypeShimmer(type: .gradient)
    }

//  Solid Animated Skeleton Type Button
    @IBAction func didTapSolidAnimatedButton(_ sender: UIButton) {
        setSkeletionAppearance(
            cornerRadius: cornerRadius,
            lastLineFillPercent: lastLineFillPercent,
            lineSpacing: lineSpacing,
            lineHeight: lineHeight
        )
        selectSekeltonTypeShimmer(type: .solidAnimated)
    }

//  Gradient Animated Skeleton Type Button
    @IBAction func didTapGradientAnimatedButton(_ sender: UIButton) {
        setSkeletionAppearance(
            cornerRadius: cornerRadius,
            lastLineFillPercent: lastLineFillPercent,
            lineSpacing: lineSpacing,
            lineHeight: lineHeight
        )
        selectSekeltonTypeShimmer(type: .gradientAnimated)
    }

//  Corner Radius Set
    @IBAction func didTapLineCornerRadiusButton(_ sender: UIButton) {
        let corRadius = Int(lineCornerRadiusTextField.text ?? "0")
        setSkeletionAppearance(
            cornerRadius: corRadius ?? 0,
            lastLineFillPercent: lastLineFillPercent,
            lineSpacing: lineSpacing,
            lineHeight: lineHeight
        )
        selectSekeltonTypeShimmer(type: skeletonChoice ?? .gradientAnimated)
        cornerRadius = corRadius ?? 0
    }

//  Last Line Fill Percent
    @IBAction func didTaplastLineFillPercentButton(_ sender: UIButton) {
        let lastLinePercent = Int(lastLineFillPercentTextField.text ?? "70")
        setSkeletionAppearance(
            cornerRadius: cornerRadius,
            lastLineFillPercent: lastLinePercent ?? 70,
            lineSpacing: lineSpacing,
            lineHeight: lineHeight
        )
        selectSekeltonTypeShimmer(type: skeletonChoice ?? .gradientAnimated)
        lastLineFillPercent = lastLinePercent ?? 70
    }

//  Line Spacing
    @IBAction func didTapLineSpacingButton(_ sender: UIButton) {
        var lineSpace: CGFloat = 10
        if let doubleLineSpace = Double(lineSpacingTextField.text ?? "10") {
            lineSpace = CGFloat(doubleLineSpace)
        }
        setSkeletionAppearance(
            cornerRadius: cornerRadius,
            lastLineFillPercent: lastLineFillPercent,
            lineSpacing: lineSpace,
            lineHeight: lineHeight
        )
        selectSekeltonTypeShimmer(type: skeletonChoice ?? .gradientAnimated)
        lineSpacing = lineSpace
    }

//    Line Height
    @IBAction func didTapLineHeightButton(_ sender: UIButton) {
        var height: CGFloat = 15
        if let doubleLineHeight = Double(lineHeightTextField.text ?? "15") {
            height = CGFloat(doubleLineHeight)
        }
        setSkeletionAppearance(
            cornerRadius: cornerRadius,
            lastLineFillPercent: lastLineFillPercent,
            lineSpacing: lineSpacing,
            lineHeight: height
        )
        selectSekeltonTypeShimmer(type: skeletonChoice ?? .gradientAnimated)
        lineHeight = height
    }

//  Next Button to Demo Table View VC
    @IBAction func didTapTableViewButton(_ sender: UIButton) {
        let tableViewVC = self.storyboard?.instantiateViewController(withIdentifier: "tableViewDemoController") as! TableDemoViewController
        self.navigationController?.pushViewController(tableViewVC, animated: true)
    }
}

// Selecting Sekelton Type Functionality
extension ViewController {
    private func selectSekeltonTypeShimmer(type: SkeletonViewChoice) {
        let gradient = SkeletonGradient(baseColor: UIColor.amethyst)
        let animation = SkeletonAnimationBuilder().makeSlidingAnimation(withDirection: .rightLeft)
        switch type {
        case .solid:
            if buttonOn {
                hideSkeleton()
                profileImageView.showSkeleton(usingColor: UIColor.amethyst)
                profileNameLabel.showSkeleton(usingColor: UIColor.amethyst)
                profileDescriptionLabel.showSkeleton(usingColor: UIColor.amethyst)
                aboutLabel.showSkeleton(usingColor: UIColor.amethyst)
                skeletonChoice = .solid
            }
        case .gradient:
            if buttonOn {
                hideSkeleton()
                profileImageView.showGradientSkeleton(usingGradient: gradient)
                profileNameLabel.showGradientSkeleton(usingGradient: gradient)
                profileDescriptionLabel.showGradientSkeleton(usingGradient: gradient)
                aboutLabel.showGradientSkeleton(usingGradient: gradient)
                skeletonChoice = .gradient
            }
        case .solidAnimated:
            if buttonOn {
                hideSkeleton()
                profileImageView.showAnimatedSkeleton(usingColor: UIColor.amethyst)
                profileNameLabel.showAnimatedSkeleton(usingColor: UIColor.amethyst)
                profileDescriptionLabel.showAnimatedSkeleton(usingColor: UIColor.amethyst)
                aboutLabel.showAnimatedSkeleton(usingColor: UIColor.amethyst)
                skeletonChoice = .solidAnimated
            }
        case .gradientAnimated:
            if buttonOn {
                hideSkeleton()
                profileImageView.showAnimatedGradientSkeleton(usingGradient: gradient, animation: animation)
                profileNameLabel.showAnimatedGradientSkeleton(usingGradient: gradient, animation: animation)
                profileDescriptionLabel.showAnimatedGradientSkeleton(usingGradient: gradient, animation: animation)
                aboutLabel.showAnimatedGradientSkeleton(usingGradient: gradient, animation: animation)
                skeletonChoice = .gradientAnimated
            }
        }
    }

//  Skeleton View Appearance
    private func setSkeletionAppearance(cornerRadius: Int, lastLineFillPercent: Int, lineSpacing: CGFloat, lineHeight: CGFloat) {
        profileNameLabel.linesCornerRadius = cornerRadius
        profileDescriptionLabel.linesCornerRadius = cornerRadius
        aboutLabel.linesCornerRadius = cornerRadius

        profileNameLabel.lastLineFillPercent = lastLineFillPercent
        profileDescriptionLabel.lastLineFillPercent = lastLineFillPercent
        aboutLabel.lastLineFillPercent = lastLineFillPercent

        profileNameLabel.skeletonLineSpacing = lineSpacing
        profileDescriptionLabel.skeletonLineSpacing = lineSpacing
        aboutLabel.skeletonLineSpacing = lineSpacing

        profileNameLabel.skeletonTextLineHeight = .fixed(lineHeight)
        profileDescriptionLabel.skeletonTextLineHeight = .fixed(lineHeight)
        aboutLabel.skeletonTextLineHeight = .fixed(lineHeight)
    }

//  Hide SkeletonView
    private func hideSkeleton() {
        profileNameLabel.hideSkeleton(transition: .crossDissolve(0.25))
        profileImageView.hideSkeleton(transition: .crossDissolve(0.25))
        profileDescriptionLabel.hideSkeleton(transition: .crossDissolve(0.25))
        aboutLabel.hideSkeleton(transition: .crossDissolve(0.25))
    }

//  Reset SkeletonView Appearance
    private func resetSkeletonApperance() {
        lineCornerRadiusTextField.text = ""
        lastLineFillPercentTextField.text = ""
        lineSpacingTextField.text = ""
        lineHeightTextField.text = ""

        cornerRadius = 0
        lastLineFillPercent = 70
        lineSpacing = 10
        lineHeight = 15
    }
}

// Instructions setup
extension ViewController: CoachMarksControllerDataSource, CoachMarksControllerDelegate {
    func numberOfCoachMarks(for coachMarksController: Instructions.CoachMarksController) -> Int {
        return 9
    }

    func coachMarksController(_ coachMarksController: CoachMarksController, coachMarkAt index: Int) -> CoachMark {
        switch index {
        case 0: return coachMarksController.helper.makeCoachMark(for: profileImageView)
        case 1: return coachMarksController.helper.makeCoachMark(for: profileNameLabel)
        case 2: return coachMarksController.helper.makeCoachMark(for: profileDescriptionLabel)
        case 3: return coachMarksController.helper.makeCoachMark(for: aboutLabel)
        case 4: return coachMarksController.helper.makeCoachMark(for: skeletonSwitch)
        case 5: return coachMarksController.helper.makeCoachMark(for: skeletonTypeView)
        case 6: return coachMarksController.helper.makeCoachMark(for: skeletonPropertyView)
        case 7: return coachMarksController.helper.makeCoachMark(for: showTableViewButton)
        case 8: return coachMarksController.helper.makeCoachMark()

        default: return coachMarksController.helper.makeCoachMark()
        }
    }

    func coachMarksController(_ coachMarksController: Instructions.CoachMarksController, coachMarkViewsAt index: Int, madeFrom coachMark: Instructions.CoachMark) -> (bodyView: (UIView & Instructions.CoachMarkBodyView), arrowView: (UIView & Instructions.CoachMarkArrowView)?) {

        let coachViews = coachMarksController.helper.makeDefaultCoachViews(withArrow: true, arrowOrientation: coachMark.arrowOrientation)

        switch index {
        case 0:
            coachViews.bodyView.hintLabel.text = "Hello! this is Profile Image for Shimmer!"
            coachViews.bodyView.nextLabel.text = "OK!!"
        case 1:
            coachViews.bodyView.hintLabel.text = "This is Name for Shimmer!"
            coachViews.bodyView.nextLabel.text = "OK!!"
        case 2:
            coachViews.bodyView.hintLabel.text = "This is Description for Shimmer!"
            coachViews.bodyView.nextLabel.text = "OK!!"
        case 3:
            coachViews.bodyView.hintLabel.text = "This is About Label for Shimmer!"
            coachViews.bodyView.nextLabel.text = "OK!!"
        case 4:
            coachViews.bodyView.hintLabel.text = "Switch for Starting Skeleton Shimmer!"
            coachViews.bodyView.nextLabel.text = "OK!!"
        case 5:
            coachViews.bodyView.hintLabel.text = "Drop option to Select Skeleton Type!"
            coachViews.bodyView.nextLabel.text = "OK!!"
            skeletonType.forEach { (Button) in
                UIView.animate(withDuration: 0.3, animations: {
                    Button.isHidden = !Button.isHidden
                    self.view.layoutIfNeeded()
                })
            }
        case 6:
            coachViews.bodyView.hintLabel.text = "Properties of Skeleton View!"
            coachViews.bodyView.nextLabel.text = "OK!!"
            skeletonType.forEach { (Button) in
                UIView.animate(withDuration: 0.3, animations: {
                    Button.isHidden = !Button.isHidden
                    self.view.layoutIfNeeded()
                })
            }
        case 7:
            coachViews.bodyView.hintLabel.text = "Skeleton View Example Using Table View!"
            coachViews.bodyView.nextLabel.text = "OK!!"
        case 8:
            self.coachMarksController.stop(immediately: true)
            keyboardHandler()

        default: break
        }

        return (bodyView: coachViews.bodyView, arrowView: coachViews.arrowView)
    }
}
 
// Keyboard Management
extension ViewController {

    private func keyboardHandler() {
        let tap = UITapGestureRecognizer(
            target: self,
            action: #selector(UIInputViewController.dismissKeyboard)
        )
        view.addGestureRecognizer(tap)

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(keyboardWillShow),
            name: UIResponder.keyboardWillShowNotification,
            object: nil
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(keyboardWillHide),
            name: UIResponder.keyboardWillHideNotification,
            object: nil
        )
    }

    @objc func dismissKeyboard() {
        view.endEditing(true)
    }

    @objc func keyboardWillShow(notification: NSNotification) {
        if ((notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey]
             as? NSValue)?.cgRectValue) != nil {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= 200
            }
        }
    }

    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }

}
