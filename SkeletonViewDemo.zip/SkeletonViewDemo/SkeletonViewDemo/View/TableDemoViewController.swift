//
//  TableDemoViewController.swift
//  SkeletonViewDemo
//
//  Created by Amam Pratap Singh on 19/01/23.
//

import UIKit
import SkeletonView

class TableDemoViewController: UIViewController {

    @IBOutlet var mainTableView: UITableView!
    @IBOutlet var loadUnloadSegmentControl: UISegmentedControl!

    private let viewModel = ProfileDataModel()
    private var dataLoaded: Bool = true

    override func viewDidLoad() {
        super.viewDidLoad()

        configTheme()
        configDependency()
    }

    private func configTheme() {
        self.navigationItem.title = "Table View Demo"
//        changeButtonColour()
    }

    private func configDependency() {
        mainTableView.dataSource = self
        mainTableView.delegate = self
    }

    @IBAction func didTapLoadUnloadSegmentControl(_ sender: UISegmentedControl) {
        switch loadUnloadSegmentControl.selectedSegmentIndex{
        case 0:
            dataLoaded = true
            self.mainTableView.reloadData()
        case 1:
            dataLoaded = false
            self.mainTableView.reloadData()
        default:
            break
        }
    }
}

extension TableDemoViewController: UITableViewDataSource, UITableViewDelegate {
//  Table view workø
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: DemoTableViewCell.identifier, for: indexPath) as! DemoTableViewCell
        cell.setData(loaded: dataLoaded)
        let profileValue = viewModel.data[indexPath.row]
        cell.nameLabel.text = profileValue.title
        cell.DescriptionLabel.text = profileValue.description
        cell.profileImageView.image = UIImage(named: profileValue.image)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
}
